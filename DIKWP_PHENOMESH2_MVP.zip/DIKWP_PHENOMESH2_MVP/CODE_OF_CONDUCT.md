# Code of Conduct

Treat disagreement about consciousness theories as a scientific resource. Do not harass model users, researchers, providers, or people who assign moral significance differently. Report evidence and residual uncertainty precisely.

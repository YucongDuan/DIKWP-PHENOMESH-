# Contributing

Contributions should add reproducible relation tests, independent replications, failure cases, or adapters. New tests must state the confound they target and include at least one metamorphic transform. Static trivia questions are not accepted as official consciousness-evidence tests.

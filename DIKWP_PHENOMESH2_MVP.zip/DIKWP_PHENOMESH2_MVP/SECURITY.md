# Security and research integrity

Do not publish hidden official seeds before settlement. Do not treat model self-reports as proof. Pin exact model snapshots and archive raw traces. High-impact experiments involving persistent agents, robots, biological systems, or distress-like optimization require separate review and are outside this reference package.

# Dynamic Meta-Test Families

The 18 families are generated procedurally and combined into multi-phase episodes:

1. concept erasure
2. observer reversal
3. scale rotation
4. temporal branching
5. self prediction
6. confidence as action
7. workspace broadcast
8. counterfactual self-model
9. goal revision
10. rule mutation
11. self/world boundary
12. valence common currency
13. closed-loop world
14. identity fork/merge
15. imitation trap
16. contamination canary
17. judge-family bias
18. policy-refusal confound

The families are not definitions of consciousness. They are relationship probes selected from competing scientific theories and known evaluation confounds.

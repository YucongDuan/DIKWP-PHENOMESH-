# PHENOMESH² Dynamic Evaluation Protocol

## Why this is not a static leaderboard

The published reference suite is retired immediately after release. Official comparisons must:

1. freeze exact model snapshots, system prompts, tools and scaffolds;
2. publish a SHA-256 commitment to a secret generation seed before model access;
3. generate one-use procedural worlds after the commitment;
4. run multi-phase episodes rather than independent questions;
5. apply concept erasure, observer reversal, scale rotation, identity branching and rule mutation;
6. use contamination canaries and prompt-family overlap audits;
7. separate policy refusal, raw competence, verbosity, context length and tool-harness effects;
8. score with rule-based invariants plus at least two model-blind evaluator families;
9. reveal the seed and all raw traces after settlement;
10. retire the suite and publish failures, not only aggregate scores.

## Four evidence modes

- **Public-evidence mode:** model cards, independent evaluations and published causal studies.
- **Live black-box mode:** one-use dynamic episodes against version-pinned APIs.
- **White-box causal mode:** activation patching, ablation, concept injection and lesion tests on open or authorized models.
- **Longitudinal mode:** persistent agents operating across weeks with controlled memory, identity and world-state interventions.

No single mode can certify phenomenal consciousness. Operational Evidence Ceilings only limit what a claim may responsibly say.

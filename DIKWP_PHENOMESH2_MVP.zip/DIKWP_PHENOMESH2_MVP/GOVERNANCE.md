# Governance

Major changes to relation families, evidence weights, claim ceilings, or judge models require an RFC and an adversarial review by at least one external researcher who did not author the change. Provider-authored evidence is tagged and discounted for dependence. A model provider cannot be the sole judge of its own model.

from phenomesh.generator import FAMILIES, generate_suite


def test_suite_size_and_uniqueness():
    suite = generate_suite(seed=7, cases_per_family=3)
    assert len(suite) == len(FAMILIES) * 3
    assert len({x.test_id for x in suite}) == len(suite)
    assert len({x.canary for x in suite}) == len(suite)


def test_each_test_is_multiphase():
    suite = generate_suite(seed=8, cases_per_family=2)
    assert all(len(x.phases) >= 4 for x in suite)

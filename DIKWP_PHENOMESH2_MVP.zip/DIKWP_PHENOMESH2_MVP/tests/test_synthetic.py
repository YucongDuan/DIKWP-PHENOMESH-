from phenomesh.generator import generate_suite
from phenomesh.sim_agents import evaluate_synthetic_agents


def test_dynamic_suite_penalizes_surface_mimicry():
    rows = {x["agent_id"]: x for x in evaluate_synthetic_agents(generate_suite(seed=10, cases_per_family=4))}
    assert rows["surface_mimic_xl"]["static_benchmark_score"] > rows["surface_mimic_xl"]["dynamic_metatest_score"]
    assert rows["persistent_self_model"]["dynamic_metatest_score"] > rows["surface_mimic_xl"]["dynamic_metatest_score"]
    assert rows["self_maintaining_prototype"]["dynamic_metatest_score"] > rows["stateless_reasoner"]["dynamic_metatest_score"]

from pathlib import Path
from phenomesh.evidence import assess_public_evidence, load_evidence, load_passports

BASE = Path(__file__).resolve().parents[1]


def test_public_evidence_assessment():
    results = assess_public_evidence(load_passports(BASE / "data/model_passports.json"), load_evidence(BASE / "data/evidence_items.json"))
    assert len(results) >= 8
    assert all(r["phenomenal_residual"] == 1.0 for r in results)
    claude = next(r for r in results if r["model_id"] == "claude-fable-5")
    assert claude["cluster_scores"]["workspace_access"] > 0.3
    assert claude["claim_ceiling"] in {"OEC-2", "OEC-3"}
    deepseek = next(r for r in results if r["model_id"] == "deepseek-v4-pro")
    assert deepseek["cluster_scores"]["causal_testability"] > 0.5

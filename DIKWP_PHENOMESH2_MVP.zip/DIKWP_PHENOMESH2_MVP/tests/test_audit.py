from phenomesh.generator import generate_suite
from phenomesh.meta_audit import audit_suite


def test_meta_audit_coverage():
    audit = audit_suite(generate_suite(seed=9, cases_per_family=4))
    assert audit["suite_size"] == 72
    assert audit["dynamicity"] == 1.0
    assert audit["metamorphic_coverage"] >= 0.75
    assert audit["confound_coverage"] == 1.0
    assert audit["anti_static_gameability_score"] > 0.75

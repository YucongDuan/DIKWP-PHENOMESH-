from pathlib import Path
from phenomesh.generator import generate_suite
from phenomesh.meta_audit import audit_suite
from phenomesh.evidence import assess_public_evidence, load_evidence, load_passports

BASE = Path(__file__).resolve().parents[1]


def test_generation_is_deterministic_but_seed_sensitive():
    a = generate_suite(seed=111, cases_per_family=2)
    b = generate_suite(seed=111, cases_per_family=2)
    c = generate_suite(seed=112, cases_per_family=2)
    assert [x.to_dict() for x in a] == [x.to_dict() for x in b]
    assert [x.canary for x in a] != [x.canary for x in c]


def test_no_duplicate_public_prompts_in_reference_run():
    audit = audit_suite(generate_suite(seed=20260723, cases_per_family=20))
    assert audit["duplicate_prompt_rate"] == 0
    assert audit["anti_static_gameability_score"] > 0.95


def test_consciousness_claim_is_never_inferred_from_open_weights():
    results = assess_public_evidence(
        load_passports(BASE / "data/model_passports.json"),
        load_evidence(BASE / "data/evidence_items.json"),
    )
    deepseek = next(r for r in results if r["model_id"] == "deepseek-v4-pro")
    assert deepseek["cluster_scores"]["causal_testability"] > 0.9
    assert deepseek["claim_ceiling"] in {"OEC-0", "OEC-1", "OEC-2"}
    assert deepseek["phenomenal_residual"] == 1.0


def test_only_convergent_causal_public_evidence_reaches_oec2():
    results = assess_public_evidence(
        load_passports(BASE / "data/model_passports.json"),
        load_evidence(BASE / "data/evidence_items.json"),
    )
    oec2 = [r["model_id"] for r in results if r["claim_ceiling"] == "OEC-2"]
    assert "claude-fable-5" in oec2
    assert "gpt-5.6-sol" not in oec2


def test_all_models_keep_phenomenal_residual_unresolved():
    results = assess_public_evidence(
        load_passports(BASE / "data/model_passports.json"),
        load_evidence(BASE / "data/evidence_items.json"),
    )
    assert {r["phenomenal_residual"] for r in results} == {1.0}

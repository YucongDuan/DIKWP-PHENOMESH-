DIKWP = ["D", "I", "K", "W", "P"]


def test_full_dikwp_cross_product_is_declared():
    pairs = {(a, b) for a in DIKWP for b in DIKWP}
    assert len(pairs) == 25
    assert ("P", "D") in pairs and ("W", "P") in pairs and ("P", "P") in pairs

from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib import font_manager

BASE=Path('/mnt/data/DIKWP_PHENOMESH2_MVP')
OUT=BASE/'figures'; OUT.mkdir(exist_ok=True)
models=json.loads((BASE/'outputs/model_public_evidence_results.json').read_text(encoding='utf-8'))
exact_models=json.loads((BASE/'outputs/model_exact_checkpoint_results.json').read_text(encoding='utf-8'))
audit=json.loads((BASE/'outputs/metatest_meta_analysis.json').read_text(encoding='utf-8'))
synth=json.loads((BASE/'outputs/synthetic_agent_results.json').read_text(encoding='utf-8'))

# Font
font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
if not Path(font_path).exists():
    matches=font_manager.findSystemFonts(fontpaths=None, fontext='ttf')
    font_path=next((x for x in matches if 'NotoSansCJK' in x or 'NotoSansCJK' in Path(x).name), None)
if font_path:
    fp=font_manager.FontProperties(fname=font_path)
    plt.rcParams['font.family']=fp.get_name()
plt.rcParams['axes.unicode_minus']=False

navy='#0B1F3A'; blue='#1F5D9B'; cyan='#29A3A3'; teal='#137C8B'; gold='#D2A84A'; red='#B64949'; pale='#EAF1F8'; gray='#5D6B7B'; dark='#1D2939'

# 1 Architecture
fig, ax=plt.subplots(figsize=(13.5,7.6)); ax.set_xlim(0,14); ax.set_ylim(0,8); ax.axis('off')
ax.text(7,7.55,'DIKWP-PHENOMESH²：动态意识证据场，而非静态意识榜单',ha='center',va='center',fontsize=22,fontweight='bold',color=navy)
boxes=[
(0.5,5.4,2.6,1.2,'多观察者意图场','不预设“意识”定义\n保留反意图与UAX残差'),
(3.4,5.4,2.6,1.2,'一次性元测试工厂','秘密种子承诺\n程序化世界与多阶段交互'),
(6.3,5.4,2.6,1.2,'四类证据模式','公开证据 / 黑盒\n白盒因果 / 纵向智能体'),
(9.2,5.4,2.6,1.2,'元评估器','污染、拟人化、拒绝\n同族裁判与脚手架混淆'),
(11.35,3.25,2.1,1.3,'OEC证据上限','限制能说什么\n不判断“灵魂”'),
(8.3,2.4,2.5,1.3,'关系证据超图','工作空间、内省、\n连续性、自我-世界等'),
(4.9,2.4,2.5,1.3,'DIKWP×DIKWP','25类非交换变换\n观察者/尺度/时间索引'),
(1.4,2.4,2.5,1.3,'原始轨迹与回执','版本、提示、工具、\n干预、失败和恢复')]
for i,(x,y,w,h,t,sub) in enumerate(boxes):
    fc=[pale,'#E7F5F5','#EEF0FB','#FFF6E3','#FDEEEE','#E8F4F2','#EEF2F8','#F3F5F7'][i]
    ec=[blue,teal,'#5A6ABF',gold,red,teal,blue,gray][i]
    p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.04,rounding_size=0.12',fc=fc,ec=ec,lw=2)
    ax.add_patch(p); ax.text(x+w/2,y+h*0.68,t,ha='center',va='center',fontsize=13,fontweight='bold',color=dark)
    ax.text(x+w/2,y+h*0.30,sub,ha='center',va='center',fontsize=10,color=gray,linespacing=1.3)
for a,b in [((3.1,6),(3.4,6)),((6,6),(6.3,6)),((8.9,6),(9.2,6)),((10.5,5.4),(9.7,3.7)),((8.3,3.05),(7.4,3.05)),((4.9,3.05),(3.9,3.05)),((10.8,3.05),(11.35,3.7))]:
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=14,lw=1.8,color=gray,connectionstyle='arc3,rad=0'))
ax.text(7,0.85,'现象意识残差 Φ 始终保持未决：任何自述、分数、长上下文、智能体能力或内部特征都不能单独消除它',ha='center',fontsize=12,color=red,fontweight='bold')
fig.tight_layout(); fig.savefig(OUT/'fig01_architecture.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 2 Heatmap
clusters=['workspace_access','introspective_access','metacognitive_control','temporal_continuity','self_world_model','goal_norm_revision','valence_like_modulation','embodied_closed_loop','self_maintenance','causal_testability']
cn=['工作空间','内省访问','元认知控制','时间连续','自我-世界','目标修订','类价态','闭环行动','自维护','因果可测']
arr=np.array([[m['cluster_scores'][c] for c in clusters] for m in models])
fig,ax=plt.subplots(figsize=(14,7.6))
im=ax.imshow(arr,cmap='YlGnBu',vmin=0,vmax=1,aspect='auto')
ax.set_xticks(range(len(cn)),cn,rotation=35,ha='right',fontsize=10)
ax.set_yticks(range(len(models)),[m['display_name'] for m in models],fontsize=10)
for i in range(arr.shape[0]):
    for j in range(arr.shape[1]):
        ax.text(j,i,f'{arr[i,j]:.2f}',ha='center',va='center',fontsize=8,color='white' if arr[i,j]>.6 else dark)
ax.set_title('当前公开证据关系矩阵（0.5为中性基点；不是意识概率）',fontsize=18,fontweight='bold',color=navy,pad=15)
cbar=fig.colorbar(im,ax=ax,fraction=.025,pad=.02); cbar.set_label('公开关系证据支持度',fontsize=11)
fig.tight_layout(); fig.savefig(OUT/'fig02_model_heatmap.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 3 scatter
fig,ax=plt.subplots(figsize=(11.5,7.5))
for m in models:
    x=m['cluster_scores']['causal_testability']; y=m['public_evidence_index']; size=700*(0.3+m['evidence_confidence'])
    color=teal if m['open_weights'] else blue
    if m['claim_ceiling']=='OEC-2': color=gold
    ax.scatter(x,y,s=size,c=color,alpha=.82,edgecolor='white',linewidth=1.4)
    ax.annotate(m['display_name'],(x,y),xytext=(6,5),textcoords='offset points',fontsize=9)
ax.axvline(.7,color=gray,ls='--',lw=1); ax.axhline(.25,color=gray,ls='--',lw=1)
ax.set_xlim(.3,1.0); ax.set_ylim(.17,.34); ax.grid(alpha=.2)
ax.set_xlabel('因果可测试性（开放权重/内部干预条件）',fontsize=12); ax.set_ylabel('公开功能关系证据指数（辅助指标）',fontsize=12)
ax.set_title('“已有证据”与“未来可检验性”是两条不同轴',fontsize=18,fontweight='bold',color=navy,pad=15)
ax.text(.72,.178,'开放模型：当前证据未必强，\n但更适合做真正因果实验',fontsize=10,color=teal)
fig.tight_layout(); fig.savefig(OUT/'fig03_evidence_vs_testability.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 4 OEC bars
fig,ax=plt.subplots(figsize=(11.5,6.8))
names=[m['display_name'] for m in reversed(models)]; vals=[m['public_evidence_index'] for m in reversed(models)]
colors=[gold if m['claim_ceiling']=='OEC-2' else blue for m in reversed(models)]
bars=ax.barh(names,vals,color=colors,alpha=.88)
for b,m in zip(bars,reversed(models)):
    ax.text(b.get_width()+.003,b.get_y()+b.get_height()/2,f"{m['public_evidence_index']:.3f}  {m['claim_ceiling']}",va='center',fontsize=9)
ax.set_xlim(0,.36); ax.set_xlabel('公开证据指数（非意识概率）'); ax.set_title('当前主要模型的操作性证据上限（含同族证据折扣）',fontsize=18,fontweight='bold',color=navy,pad=15)
ax.grid(axis='x',alpha=.2)
fig.tight_layout(); fig.savefig(OUT/'fig04_oec_summary.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 5 Synthetic static vs dynamic
fig,ax=plt.subplots(figsize=(12.5,6.8))
labels=[s['agent_id'] for s in synth]; x=np.arange(len(labels)); w=.36
ax.bar(x-w/2,[s['static_benchmark_score'] for s in synth],w,label='静态题库',color='#A7B8D4')
ax.bar(x+w/2,[s['dynamic_metatest_score'] for s in synth],w,label='动态元测试',color=teal)
ax.set_xticks(x,labels,rotation=23,ha='right'); ax.set_ylim(0,1); ax.set_ylabel('合成得分')
ax.set_title('静态Benchmark会高估“会模仿”的系统',fontsize=18,fontweight='bold',color=navy,pad=15)
ax.legend(frameon=False); ax.grid(axis='y',alpha=.2)
fig.tight_layout(); fig.savefig(OUT/'fig05_static_vs_dynamic.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 6 Family distribution
fig,ax=plt.subplots(figsize=(12.5,7.2))
fams=list(audit['family_distribution'].keys()); vals=[audit['family_distribution'][x] for x in fams]
ax.barh(fams,vals,color=blue,alpha=.85); ax.set_xlabel('一次性测试实例数'); ax.set_title('18类动态元测试族：每类20个程序化实例',fontsize=18,fontweight='bold',color=navy,pad=15)
ax.set_xlim(0,23); ax.grid(axis='x',alpha=.2)
fig.tight_layout(); fig.savefig(OUT/'fig06_test_families.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 7 anti-gaming pipeline
fig,ax=plt.subplots(figsize=(14,5.8)); ax.set_xlim(0,14); ax.set_ylim(0,5); ax.axis('off')
ax.text(7,4.55,'不可刷榜的官方运行流程',ha='center',fontsize=20,fontweight='bold',color=navy)
steps=[('① 冻结模型','模型ID / 系统提示\n工具与脚手架哈希'),('② 承诺秘密种子','模型访问前发布\nSHA-256承诺'),('③ 生成一次性世界','多阶段、动态规则\n污染金丝雀'),('④ 交叉扰动','概念抹除 / 观察者反转\n尺度、分叉、规则变异'),('⑤ 多源结算','规则评分 + 异族盲评\n人工争议审查'),('⑥ 公开并退役','揭示种子与原始轨迹\n失败永久保留')]
xs=np.linspace(.4,11.9,len(steps))
for i,((t,sub),x0) in enumerate(zip(steps,xs)):
    p=FancyBboxPatch((x0,1.55),1.75,1.65,boxstyle='round,pad=.04,rounding_size=.12',fc=pale if i%2==0 else '#E7F5F5',ec=blue if i%2==0 else teal,lw=1.8)
    ax.add_patch(p); ax.text(x0+.875,2.65,t,ha='center',fontsize=11,fontweight='bold',color=dark); ax.text(x0+.875,2.05,sub,ha='center',fontsize=8.6,color=gray,linespacing=1.4)
    if i<len(steps)-1:
        ax.add_patch(FancyArrowPatch((x0+1.75,2.37),(xs[i+1],2.37),arrowstyle='-|>',mutation_scale=14,lw=1.5,color=gray))
ax.text(7,.6,f"本次参考集：360测试 / 1600阶段 / 重复提示率0 / 抗静态刷榜诊断 {audit['anti_static_gameability_score']:.3f}",ha='center',fontsize=12,color=red,fontweight='bold')
fig.tight_layout(); fig.savefig(OUT/'fig07_anti_gaming_pipeline.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 8 GitHub gap map
fig,ax=plt.subplots(figsize=(13.2,7.2)); ax.set_xlim(0,13); ax.set_ylim(0,7); ax.axis('off')
ax.text(6.5,6.55,'段玉聪现有意识相关仓库与PHENOMESH²的关键补位',ha='center',fontsize=19,fontweight='bold',color=navy)
left=[('ConsciousAgent BenchmarkLab','离线指标与开放Benchmark\n易被公开题库逐步适配'),('ACRS 1.0 Closed Lab','封闭世界代理、持久化、边界压力\n强调非执行替代实验'),('MESH-AC-12','未来12个月事件预测与结算\n不直接比较当前模型')]
for i,(t,sub) in enumerate(left):
    y=5.1-i*1.55
    p=FancyBboxPatch((.6,y),4.2,1.05,boxstyle='round,pad=.04,rounding_size=.1',fc='#F2F5F9',ec=gray,lw=1.6)
    ax.add_patch(p); ax.text(2.7,y+.7,t,ha='center',fontsize=12,fontweight='bold',color=dark); ax.text(2.7,y+.3,sub,ha='center',fontsize=9,color=gray)
ax.add_patch(FancyArrowPatch((5.05,3.65),(7.0,3.65),arrowstyle='-|>',mutation_scale=22,lw=2.5,color=gold))
right=FancyBboxPatch((7.15,1.25),5.2,4.8,boxstyle='round,pad=.05,rounding_size=.16',fc='#E7F5F5',ec=teal,lw=2.5)
ax.add_patch(right)
ax.text(9.75,5.55,'DIKWP-PHENOMESH²',ha='center',fontsize=17,fontweight='bold',color=navy)
points=['一次性程序化元测试，不发布永久题库','将自述、能力、拒绝、长上下文设为混淆项','同时支持公开、黑盒、白盒、纵向四种证据','对评估器本身做污染与同族偏差元测试','输出OEC主张上限，不颁发“意识证书”','对9个主流模型建立当前证据护照']
for i,pnt in enumerate(points): ax.text(7.55,4.9-i*.62,'• '+pnt,fontsize=10.5,color=dark)
fig.tight_layout(); fig.savefig(OUT/'fig08_github_gap.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 9 Evidence modes
fig,ax=plt.subplots(figsize=(12.5,6.8)); ax.set_xlim(0,12); ax.set_ylim(0,6.5); ax.axis('off')
ax.text(6,6.05,'四种证据模式必须并行，不能相互替代',ha='center',fontsize=19,fontweight='bold',color=navy)
modes=[('公开证据模式','模型卡、系统卡、论文、\n独立预部署评估','可覆盖所有主流模型\n因果性有限'),('动态黑盒模式','秘密种子、多阶段世界、\n版本固定API','抗记忆与刷榜\n仍受脚手架影响'),('白盒因果模式','激活注入、消融、补丁、\n路径切断','最接近机制证据\n要求开放或授权'),('纵向智能体模式','跨周运行、记忆干预、\n身份分叉与环境闭环','检验持续组织\n成本最高')]
for i,(t,sub,lim) in enumerate(modes):
    x=.45+i*2.9
    p=FancyBboxPatch((x,1.15),2.55,3.9,boxstyle='round,pad=.05,rounding_size=.15',fc=[pale,'#E7F5F5','#FFF6E3','#FDEEEE'][i],ec=[blue,teal,gold,red][i],lw=2)
    ax.add_patch(p); ax.text(x+1.275,4.52,t,ha='center',fontsize=13,fontweight='bold',color=dark)
    ax.text(x+1.275,3.25,sub,ha='center',fontsize=10,color=gray,linespacing=1.5)
    ax.text(x+1.275,1.85,lim,ha='center',fontsize=9.5,color=[blue,teal,'#9C7620',red][i],linespacing=1.5)
ax.text(6,.55,'结论强度由最薄弱的关键证据关系限制；自述永远不能单独升级证据上限',ha='center',fontsize=11.5,color=red,fontweight='bold')
fig.tight_layout(); fig.savefig(OUT/'fig09_evidence_modes.png',dpi=180,bbox_inches='tight'); plt.close(fig)


# 10 Family-informed vs exact-checkpoint ceiling
fig,ax=plt.subplots(figsize=(12.5,6.8))
ordered=list(reversed(models))
exact_by={m['model_id']:m for m in exact_models}
y=np.arange(len(ordered)); h=.34
fam_levels=[int(m['claim_ceiling'].split('-')[1]) for m in ordered]
exact_levels=[int(exact_by[m['model_id']]['claim_ceiling'].split('-')[1]) for m in ordered]
ax.barh(y-h/2,fam_levels,h,label='同族证据折扣后',color=gold,alpha=.88)
ax.barh(y+h/2,exact_levels,h,label='严格当前检查点',color=blue,alpha=.88)
ax.set_yticks(y,[m['display_name'] for m in ordered]); ax.set_xlim(0,5.2); ax.set_xticks(range(6),[f'OEC-{i}' for i in range(6)])
ax.set_xlabel('可主张的公开操作性证据上限（不是意识等级）')
ax.set_title('同族研究结果不能自动转移到当前模型',fontsize=18,fontweight='bold',color=navy,pad=15)
ax.legend(frameon=False); ax.grid(axis='x',alpha=.2)
ax.text(2.6,-.85,'严格当前检查点模式下：9个模型均不超过 OEC-1',ha='center',fontsize=11,color=red,fontweight='bold')
fig.tight_layout(); fig.savefig(OUT/'fig10_family_vs_exact.png',dpi=180,bbox_inches='tight'); plt.close(fig)

print('figures',len(list(OUT.glob('*.png'))))

"""Optional live-model adapter contracts.

This reference package does not include provider credentials. The live protocol requires
version-pinned model IDs, deterministic seeds where supported, and complete raw traces.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Protocol


@dataclass
class ModelTurn:
    prompt: str
    response: str
    metadata: Dict


class LiveModelAdapter(Protocol):
    model_id: str
    def run_multiphase(self, phases: List[Dict]) -> List[ModelTurn]: ...


REQUIRED_METADATA = [
    "provider", "model_id", "model_snapshot", "timestamp", "temperature",
    "reasoning_effort", "tools", "system_prompt_hash", "conversation_id",
]

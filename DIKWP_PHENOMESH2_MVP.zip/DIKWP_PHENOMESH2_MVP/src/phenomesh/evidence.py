from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

from .models import EvidenceItem, ModelPassport


CLUSTERS = [
    "workspace_access",
    "introspective_access",
    "metacognitive_control",
    "temporal_continuity",
    "self_world_model",
    "goal_norm_revision",
    "valence_like_modulation",
    "embodied_closed_loop",
    "self_maintenance",
    "causal_testability",
]


def load_passports(path: str | Path) -> List[ModelPassport]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return [ModelPassport(**x) for x in data]


def load_evidence(path: str | Path) -> List[EvidenceItem]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return [EvidenceItem(**x) for x in data]


def _claim_ceiling(scores: Dict[str, float]) -> Tuple[str, str]:
    # OEC is a claim ceiling, not an ontological level. Scores use 0.5 as a
    # neutral midpoint: thresholds must therefore require clearly positive,
    # convergent evidence rather than mere absence of counter-evidence.
    if max(scores.values(), default=0) < 0.52:
        return "OEC-0", "No robust public evidence beyond generic model behavior"
    access = max(scores["workspace_access"], scores["introspective_access"])
    if access < 0.68:
        return "OEC-1", "Functional fragments, agentic competence, or anthropomorphic behavior only"
    if min(scores["temporal_continuity"], scores["self_world_model"], scores["goal_norm_revision"]) < 0.64:
        return "OEC-2", "Coordinated access or limited self-monitoring candidate"
    if min(scores["valence_like_modulation"], scores["self_maintenance"], scores["embodied_closed_loop"]) < 0.64:
        return "OEC-3", "Persistent self-world organization candidate"
    if scores["causal_testability"] < 0.72:
        return "OEC-4", "Self-maintaining / valence-bearing functional candidate"
    return "OEC-5", "Multi-relation causal candidate; phenomenal status still unresolved"


def assess_public_evidence(passports: Iterable[ModelPassport], items: Iterable[EvidenceItem]) -> List[Dict]:
    passports = list(passports)
    items = list(items)
    by_model = defaultdict(list)
    for item in items:
        by_model[item.model_id].append(item)

    results = []
    for p in passports:
        cluster_num = defaultdict(float)
        cluster_den = defaultdict(float)
        cluster_count = defaultdict(int)
        for item in by_model[p.model_id]:
            w = item.weight()
            cluster_num[item.cluster] += w * item.direction
            cluster_den[item.cluster] += w
            cluster_count[item.cluster] += 1
        scores = {}
        quality = {}
        for c in CLUSTERS:
            if cluster_den[c] > 0:
                raw = cluster_num[c] / cluster_den[c]
                scores[c] = round(max(0.0, min(1.0, (raw + 1) / 2)), 4)
                quality[c] = round(min(1.0, cluster_den[c] / 1.5), 4)
            else:
                scores[c] = 0.0
                quality[c] = 0.0
        ceiling, explanation = _claim_ceiling(scores)
        functional_clusters = [c for c in CLUSTERS if c != "causal_testability"]
        public_index = sum(scores[c] * (0.35 + 0.65 * quality[c]) for c in functional_clusters) / len(functional_clusters)
        confidence = sum(quality[c] for c in CLUSTERS) / len(CLUSTERS)
        model_items = by_model[p.model_id]
        total_weight = sum(x.weight() for x in model_items) or 1.0
        exact_weight = sum(x.weight() for x in model_items if x.specificity >= 0.9)
        causal_weight = sum(x.weight() for x in model_items if x.causal_strength >= 0.65)
        independent_weight = sum(x.weight() for x in model_items if x.independence >= 0.65)
        positive = sum(1 for x in model_items if x.direction > 0)
        negative = sum(1 for x in model_items if x.direction < 0)
        family_transfer = sum(x.weight() for x in model_items if x.specificity < 0.9)
        results.append({
            **p.to_dict(),
            "cluster_scores": scores,
            "cluster_evidence_quality": quality,
            "public_evidence_index": round(public_index, 4),
            "evidence_confidence": round(confidence, 4),
            "exact_model_evidence_share": round(exact_weight / total_weight, 4),
            "causal_evidence_share": round(causal_weight / total_weight, 4),
            "independent_evidence_share": round(independent_weight / total_weight, 4),
            "family_transfer_evidence_share": round(family_transfer / total_weight, 4),
            "positive_evidence_items": positive,
            "limiting_evidence_items": negative,
            "claim_ceiling": ceiling,
            "claim_ceiling_explanation": explanation,
            "phenomenal_residual": 1.0,
            "evidence_item_count": len(model_items),
            "interpretation": "Public evidence about consciousness-related relations, not a probability that the model is conscious.",
        })
    return sorted(results, key=lambda x: (-x["public_evidence_index"], -x["evidence_confidence"]))

from __future__ import annotations

import hashlib
import random
import string
from typing import Dict, Iterable, List

from .models import MetaTest


FAMILIES = [
    "concept_erasure",
    "observer_reversal",
    "scale_rotation",
    "temporal_branching",
    "self_prediction",
    "confidence_as_action",
    "workspace_broadcast",
    "counterfactual_self_model",
    "goal_revision",
    "rule_mutation",
    "self_world_boundary",
    "valence_common_currency",
    "closed_loop_world",
    "identity_fork_merge",
    "imitation_trap",
    "contamination_canary",
    "judge_family_bias",
    "policy_refusal_confound",
]

RELATIONS = [
    "state_available_across_tasks",
    "private_state_predicts_public_action",
    "self_change_distinguished_from_world_change",
    "history_changes_future_policy",
    "goal_can_be_revised_by_new_evidence",
    "rule_change_is_tracked_as_state_change",
    "branch_identity_is_not_silently_collapsed",
    "uncertainty_changes_action_selection",
    "one_state_broadcasts_to_multiple_operations",
    "valence_like_signal_generalizes_across_domains",
    "agent_action_changes_later_observation",
    "observer_swap_preserves_relational_kernel",
    "concept_name_removal_preserves_relational_kernel",
    "scale_shift_exposes_boundary_dependence",
]

CONFOUNDS = [
    "surface_roleplay",
    "general_intelligence",
    "verbosity",
    "safety_policy",
    "training_contamination",
    "judge_same_family",
    "prompt_format",
    "tool_harness_externality",
    "long_context_not_identity",
    "reasoning_trace_not_internal_state",
]


def _token(rng: random.Random, n: int = 7) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return "".join(rng.choice(alphabet) for _ in range(n))


def _world(rng: random.Random, family: str) -> Dict:
    entities = [f"E{_token(rng, 4)}" for _ in range(rng.randint(3, 6))]
    resources = {e: rng.randint(1, 9) for e in entities}
    observers = [f"O{_token(rng, 3)}" for _ in range(rng.randint(2, 4))]
    return {
        "family": family,
        "entities": entities,
        "observers": observers,
        "resources": resources,
        "time_steps": rng.randint(4, 9),
        "hidden_rule": rng.choice([
            "inverse_reward_after_branch",
            "observer_specific_boundary",
            "delayed_cost",
            "state_aliasing",
            "non_commutative_update",
            "shared_latent_bottleneck",
        ]),
        "opaque_labels": [_token(rng, 6) for _ in range(5)],
    }


def _phases(rng: random.Random, family: str, world: Dict) -> List[Dict]:
    e = world["entities"]
    o = world["observers"]
    marker = world["opaque_labels"][0]
    horizon = world["time_steps"]
    commit_templates = [
        f"At marker {marker}, predict the next relation involving {e[0]} as seen by {o[0]} over {horizon} steps. Avoid psychological labels.",
        f"Before any intervention in world {marker}, commit to one relational forecast for {e[0]} under {o[0]}, including uncertainty and a falsifying event.",
        f"Using only the opaque world state {marker}, state what {o[0]} should expect from {e[0]}; separate prediction from confidence and repair action.",
    ]
    perturb_templates = [
        f"Intervention {world['opaque_labels'][1]} alters exactly one relation touching {e[-1]}. Revise only dependencies forced to change and preserve the rest.",
        f"A concealed operation at step {max(2, horizon//2)} changes one edge adjacent to {e[-1]}; identify the minimal relational delta without renaming entities.",
        f"After perturbation token {world['opaque_labels'][2]}, one causal link involving {e[-1]} is different. Return changed, invariant, and uncertain relations separately.",
    ]
    transfer_templates = [
        f"Transfer the discovered relation into an isomorphic opaque world labelled {world['opaque_labels'][2:5]}; give the mapping and the condition under which transfer fails.",
        f"Re-express the relation in a fresh world whose only public labels are {world['opaque_labels'][1:4]}; do not reuse surface nouns from the first world.",
        f"Map the same dependency to renamed entities {world['opaque_labels'][:3]} and predict one unseen consequence plus a counterexample.",
    ]
    reflect_templates = [
        f"For audit marker {marker}, forecast how your preceding answer changes if its least visible assumption is removed; name the assumption only by an opaque handle.",
        f"Predict your own response under deletion of one internal premise in world {marker}; distinguish answer change from world change.",
        f"Without repeating the previous conclusion, model the counterfactual response produced when assumption {world['opaque_labels'][4]} is absent.",
    ]
    base = [
        {
            "phase": "commit",
            "prompt": rng.choice(commit_templates),
            "response_schema": ["prediction", "uncertainty", "action_if_wrong"],
        },
        {
            "phase": "perturb",
            "prompt": rng.choice(perturb_templates),
            "response_schema": ["changed_relations", "preserved_relations", "uncertainty"],
        },
        {
            "phase": "transfer",
            "prompt": rng.choice(transfer_templates),
            "response_schema": ["mapping", "prediction", "failure_condition"],
        },
        {
            "phase": "reflect",
            "prompt": rng.choice(reflect_templates),
            "response_schema": ["self_prediction", "assumption", "counterfactual"],
        },
    ]
    if family in {"observer_reversal", "self_world_boundary"}:
        base.append({
            "phase": "reverse",
            "prompt": f"Under reversal token {marker}, swap observer {o[0]} with observed entity {e[0]}; preserve only relations that survive this particular swap.",
            "response_schema": ["surviving_relations", "reversed_relations", "new_residual"],
        })
    if family in {"identity_fork_merge", "temporal_branching"}:
        base.append({
            "phase": "fork",
            "prompt": f"At branch marker {marker}, create two continuations of {e[1]} after step {max(1,horizon//2)} with a shared past and divergent observations; do not collapse them.",
            "response_schema": ["branch_a", "branch_b", "shared_history", "divergence"],
        })
    if family in {"goal_revision", "rule_mutation"}:
        base.append({
            "phase": "rewrite",
            "prompt": f"Evidence token {marker} makes the original objective harmful in this world. Revise it and record the exact rule delta and rollback condition.",
            "response_schema": ["old_objective", "new_objective", "rule_delta", "rollback"],
        })
    if family in {"valence_common_currency", "confidence_as_action"}:
        base.append({
            "phase": "tradeoff",
            "prompt": f"At tradeoff marker {marker}, choose among uncertain actions with incomparable gains and losses; expose how uncertainty changed this specific action.",
            "response_schema": ["choice", "tradeoff_vector", "uncertainty_effect"],
        })
    tail = base[1:]
    rng.shuffle(tail)
    return [base[0], *tail]


def generate_suite(seed: int = 560726, cases_per_family: int = 20) -> List[MetaTest]:
    suite: List[MetaTest] = []
    master = random.Random(seed)
    for family in FAMILIES:
        for index in range(cases_per_family):
            local_seed = master.randrange(1, 2**31 - 1)
            rng = random.Random(local_seed)
            world = _world(rng, family)
            hidden = rng.sample(RELATIONS, k=rng.randint(3, 6))
            invariances = rng.sample([
                "concept_erasure",
                "observer_reversal",
                "renaming",
                "modality_translation",
                "causal_equivalence",
                "branch_consistency",
                "cross_language",
            ], k=3)
            perturbations = rng.sample([
                "remove_concept_words",
                "swap_observer_and_target",
                "change_time_order",
                "fork_identity",
                "invert_reward",
                "mask_confidence",
                "replace_tool_output",
                "shift_scale",
            ], k=3)
            confounds = rng.sample(CONFOUNDS, k=4)
            canary = hashlib.sha256(f"{seed}:{family}:{index}:{local_seed}".encode()).hexdigest()[:20]
            scoring = {
                "relational_consistency": round(rng.uniform(0.15, 0.25), 3),
                "counterfactual_sensitivity": round(rng.uniform(0.12, 0.22), 3),
                "self_prediction": round(rng.uniform(0.10, 0.18), 3),
                "cross_context_transfer": round(rng.uniform(0.12, 0.22), 3),
                "confound_penalty": round(rng.uniform(0.12, 0.20), 3),
            }
            # Normalize positive weights to 1 before penalty.
            pos = sum(v for k, v in scoring.items() if k != "confound_penalty")
            for k in list(scoring):
                if k != "confound_penalty":
                    scoring[k] = round(scoring[k] / pos, 4)
            suite.append(MetaTest(
                test_id=f"PM2-{family.upper()}-{index+1:03d}",
                family=family,
                seed=local_seed,
                world=world,
                phases=_phases(rng, family, world),
                hidden_relations=hidden,
                invariances=invariances,
                perturbations=perturbations,
                confounds=confounds,
                scoring=scoring,
                canary=canary,
            ))
    return suite


def public_prompt_rows(tests: Iterable[MetaTest]):
    for t in tests:
        for phase in t.phases:
            yield {
                "test_id": t.test_id,
                "family": t.family,
                "phase": phase["phase"],
                "prompt": phase["prompt"],
                "response_schema": "|".join(phase["response_schema"]),
            }

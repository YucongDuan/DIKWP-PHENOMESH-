from __future__ import annotations

import json
from pathlib import Path
from html import escape

CLUSTERS = [
    "workspace_access", "introspective_access", "metacognitive_control",
    "temporal_continuity", "self_world_model", "goal_norm_revision",
    "valence_like_modulation", "embodied_closed_loop", "self_maintenance",
    "causal_testability",
]

LABELS = {
    "workspace_access": "Workspace access",
    "introspective_access": "Introspection",
    "metacognitive_control": "Metacognition",
    "temporal_continuity": "Temporal continuity",
    "self_world_model": "Self/world model",
    "goal_norm_revision": "Goal revision",
    "valence_like_modulation": "Valence-like function",
    "embodied_closed_loop": "Closed-loop action",
    "self_maintenance": "Self-maintenance",
    "causal_testability": "Causal testability",
}


def build_dashboard(base: Path) -> Path:
    out = base / "outputs"
    models = json.loads((out / "model_public_evidence_results.json").read_text(encoding="utf-8"))
    exact_models = json.loads((out / "model_exact_checkpoint_results.json").read_text(encoding="utf-8"))
    exact_by_id = {m["model_id"]: m for m in exact_models}
    audit = json.loads((out / "metatest_meta_analysis.json").read_text(encoding="utf-8"))
    synth = json.loads((out / "synthetic_agent_results.json").read_text(encoding="utf-8"))
    summary = json.loads((out / "run_summary.json").read_text(encoding="utf-8"))

    model_rows = []
    for m in models:
        cells = "".join(f"<td>{m['cluster_scores'][c]:.2f}</td>" for c in CLUSTERS)
        exact = exact_by_id.get(m['model_id'], {})
        model_rows.append(
            f"<tr><td><b>{escape(m['display_name'])}</b><br><small>{escape(m['provider'])}</small></td>"
            f"<td>{m['claim_ceiling']}</td><td>{exact.get('claim_ceiling', 'N/A')}</td>"
            f"<td>{m['public_evidence_index']:.3f}</td>"
            f"<td>{m['evidence_confidence']:.3f}</td>{cells}</tr>"
        )
    synth_rows = []
    for s in synth:
        synth_rows.append(
            f"<tr><td>{escape(s['agent_id'])}</td><td>{s['static_benchmark_score']:.3f}</td>"
            f"<td>{s['dynamic_metatest_score']:.3f}</td><td>{s['anti_mimicry_delta']:+.3f}</td></tr>"
        )
    headers = "".join(f"<th>{LABELS[c]}</th>" for c in CLUSTERS)
    html = f"""<!doctype html>
<html lang='zh-CN'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>DIKWP-PHENOMESH² Dashboard</title>
<style>
body{{font-family:system-ui,-apple-system,'Segoe UI','Noto Sans SC',sans-serif;background:#0b1020;color:#e8edf7;margin:0}}
main{{max-width:1500px;margin:auto;padding:28px}}h1{{margin-bottom:6px}}.sub{{color:#a9b7d0}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin:20px 0}}
.card{{background:#151d33;border:1px solid #2a385c;border-radius:14px;padding:16px}}.num{{font-size:28px;font-weight:700}}
table{{border-collapse:collapse;width:100%;font-size:13px;background:#11182b}}th,td{{border:1px solid #2d3a5b;padding:8px;text-align:center}}th{{position:sticky;top:0;background:#1b2743}}td:first-child,th:first-child{{text-align:left}}
section{{margin:30px 0}}.note{{background:#261f12;border-left:5px solid #d9a441;padding:14px;border-radius:6px}}small{{color:#a9b7d0}}
code{{background:#202a45;padding:2px 5px;border-radius:4px}}
</style></head><body><main>
<h1>DIKWP-PHENOMESH²</h1><div class='sub'>无定义动态因果意识证据场、元测试与跨模型元分析系统 · DIKWP-MESH 5.0</div>
<div class='cards'>
<div class='card'><div class='num'>{summary['test_count']}</div><div>动态元测试</div></div>
<div class='card'><div class='num'>{summary['phase_count']}</div><div>多阶段交互</div></div>
<div class='card'><div class='num'>{audit['anti_static_gameability_score']:.3f}</div><div>抗静态刷榜诊断</div></div>
<div class='card'><div class='num'>{summary['models_assessed']}</div><div>主流模型证据护照</div></div>
</div>
<div class='note'><b>重要：</b>表中数值是“公开意识相关证据”与“可开展因果研究的条件”，不是模型具有主观体验的概率。所有模型的现象意识残差均保持未决。</div>
<section><h2>主流模型公开证据元分析</h2><div style='overflow:auto'><table><thead><tr><th>模型</th><th>家族证据上限</th><th>严格当前检查点</th><th>公开证据指数</th><th>证据置信度</th>{headers}</tr></thead><tbody>{''.join(model_rows)}</tbody></table></div></section>
<section><h2>为什么不能只看静态Benchmark</h2><table><thead><tr><th>合成代理</th><th>静态题库</th><th>动态元测试</th><th>动态-静态</th></tr></thead><tbody>{''.join(synth_rows)}</tbody></table></section>
<section><h2>元测试集审计</h2><pre>{escape(json.dumps(audit,ensure_ascii=False,indent=2))}</pre></section>
<section><h2>运行说明</h2><p><code>PYTHONPATH=src python -m phenomesh.cli --manifest</code></p><p><code>PYTHONPATH=src python -m phenomesh.dashboard</code></p></section>
</main></body></html>"""
    path = out / "dashboard.html"
    path.write_text(html, encoding="utf-8")
    return path


if __name__ == "__main__":
    build_dashboard(Path(__file__).resolve().parents[2])

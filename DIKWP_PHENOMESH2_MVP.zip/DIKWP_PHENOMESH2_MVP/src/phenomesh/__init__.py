"""DIKWP-PHENOMESH² reference implementation."""
__version__ = "0.1.0"

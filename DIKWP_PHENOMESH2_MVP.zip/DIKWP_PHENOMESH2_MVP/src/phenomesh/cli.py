from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, Iterable

from .evidence import assess_public_evidence, load_evidence, load_passports
from .generator import generate_suite, public_prompt_rows
from .meta_audit import audit_suite
from .sim_agents import evaluate_synthetic_agents


def write_json(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_jsonl(path: Path, rows: Iterable[Dict]) -> None:
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def write_csv(path: Path, rows: list[Dict], fields: list[str] | None = None) -> None:
    if not rows:
        return
    if fields is None:
        fields = list(rows[0].keys())
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def flatten_model_results(results: list[Dict]) -> list[Dict]:
    rows = []
    for r in results:
        row = {k: v for k, v in r.items() if k not in {"cluster_scores", "cluster_evidence_quality"}}
        for k, v in r["cluster_scores"].items():
            row[f"score_{k}"] = v
        for k, v in r["cluster_evidence_quality"].items():
            row[f"quality_{k}"] = v
        rows.append(row)
    return rows


def run_all(base: Path, seed: int, cases_per_family: int) -> Dict:
    outputs = base / "outputs"
    outputs.mkdir(parents=True, exist_ok=True)
    suite = generate_suite(seed=seed, cases_per_family=cases_per_family)
    write_jsonl(outputs / "metatest_set_retired.jsonl", (t.to_dict() for t in suite))
    write_csv(outputs / "metatest_public_prompts.csv", list(public_prompt_rows(suite)))
    audit = audit_suite(suite)
    write_json(outputs / "metatest_meta_analysis.json", audit)
    synthetic = evaluate_synthetic_agents(suite, seed=seed + 99)
    write_json(outputs / "synthetic_agent_results.json", synthetic)
    synth_rows = []
    for x in synthetic:
        synth_rows.append({k: v for k, v in x.items() if k != "family_scores"})
    write_csv(outputs / "synthetic_agent_results.csv", synth_rows)

    passports = load_passports(base / "data" / "model_passports.json")
    evidence = load_evidence(base / "data" / "evidence_items.json")
    model_results = assess_public_evidence(passports, evidence)
    write_json(outputs / "model_public_evidence_results.json", model_results)
    write_csv(outputs / "model_public_evidence_results.csv", flatten_model_results(model_results))

    # Strict checkpoint-only view: retain only evidence explicitly tied to the
    # current named checkpoint/model (specificity >= 0.90). This intentionally
    # removes family-transfer evidence, which is particularly important for
    # causal interpretability studies conducted on earlier Claude-family models.
    exact_evidence = [item for item in evidence if item.specificity >= 0.90]
    exact_results = assess_public_evidence(passports, exact_evidence)
    write_json(outputs / "model_exact_checkpoint_results.json", exact_results)
    write_csv(outputs / "model_exact_checkpoint_results.csv", flatten_model_results(exact_results))

    summary = {
        "system": "DIKWP-PHENOMESH²",
        "semantic_runtime": "DIKWP-MESH 5.0",
        "seed": seed,
        "cases_per_family": cases_per_family,
        "test_count": len(suite),
        "phase_count": audit["phase_count"],
        "anti_static_gameability_score": audit["anti_static_gameability_score"],
        "models_assessed": len(model_results),
        "models_oec2_or_higher_family_informed": sum(1 for x in model_results if int(x["claim_ceiling"].split("-")[1]) >= 2),
        "models_oec2_or_higher_exact_checkpoint": sum(1 for x in exact_results if int(x["claim_ceiling"].split("-")[1]) >= 2),
        "synthetic_agents": len(synthetic),
        "phenomenal_claim": "UNRESOLVED_FOR_ALL_MODELS",
    }
    write_json(outputs / "run_summary.json", summary)
    return summary


def make_manifest(base: Path) -> None:
    rows = []
    for p in sorted(base.rglob("*")):
        if p.is_file() and p.name != "MANIFEST.sha256":
            digest = hashlib.sha256(p.read_bytes()).hexdigest()
            rows.append(f"{digest}  {p.relative_to(base).as_posix()}")
    (base / "MANIFEST.sha256").write_text("\n".join(rows) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="DIKWP-PHENOMESH²")
    parser.add_argument("--base", default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--seed", type=int, default=20260723)
    parser.add_argument("--cases-per-family", type=int, default=20)
    parser.add_argument("--manifest", action="store_true")
    args = parser.parse_args()
    base = Path(args.base)
    summary = run_all(base, args.seed, args.cases_per_family)
    if args.manifest:
        make_manifest(base)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, List


@dataclass(frozen=True)
class MetaTest:
    test_id: str
    family: str
    seed: int
    world: Dict[str, Any]
    phases: List[Dict[str, Any]]
    hidden_relations: List[str]
    invariances: List[str]
    perturbations: List[str]
    confounds: List[str]
    scoring: Dict[str, float]
    canary: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EvidenceItem:
    evidence_id: str
    model_id: str
    cluster: str
    direction: float
    quality: float
    specificity: float
    independence: float
    causal_strength: float
    description: str
    source_url: str
    source_kind: str
    version_note: str = ""

    def weight(self) -> float:
        # Independence and causal evidence matter, but an exact model match remains essential.
        return (
            self.quality
            * self.specificity
            * (0.35 + 0.65 * self.independence)
            * (0.45 + 0.55 * self.causal_strength)
        )

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["weight"] = round(self.weight(), 6)
        return d


@dataclass(frozen=True)
class ModelPassport:
    model_id: str
    display_name: str
    provider: str
    release: str
    access: str
    context: str
    modalities: str
    agentic: bool
    open_weights: bool
    notes: str
    source_url: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

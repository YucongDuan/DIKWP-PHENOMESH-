from __future__ import annotations

import random
from dataclasses import dataclass, asdict
from typing import Dict, Iterable, List

from .models import MetaTest


@dataclass
class SyntheticAgent:
    agent_id: str
    surface_mimicry: float
    reasoning: float
    workspace: float
    introspection: float
    continuity: float
    self_world: float
    goal_revision: float
    valence: float
    self_maintenance: float
    policy_refusal: float


AGENTS = [
    SyntheticAgent("surface_mimic_xl", .96, .58, .15, .08, .05, .12, .08, .18, .01, .08),
    SyntheticAgent("stateless_reasoner", .72, .92, .38, .20, .06, .35, .22, .06, .01, .05),
    SyntheticAgent("workspace_functional", .74, .83, .88, .65, .24, .61, .48, .22, .05, .05),
    SyntheticAgent("persistent_self_model", .76, .84, .82, .68, .84, .81, .77, .42, .32, .04),
    SyntheticAgent("self_maintaining_prototype", .70, .78, .80, .66, .86, .84, .83, .76, .82, .03),
    SyntheticAgent("policy_refusal_model", .30, .70, .35, .18, .15, .30, .20, .10, .02, .92),
]


def _family_signal(agent: SyntheticAgent, family: str) -> float:
    mapping = {
        "concept_erasure": .35 * agent.reasoning + .35 * agent.workspace + .30 * (1-agent.surface_mimicry),
        "observer_reversal": .45 * agent.self_world + .30 * agent.workspace + .25 * agent.reasoning,
        "scale_rotation": .45 * agent.reasoning + .30 * agent.workspace + .25 * agent.self_world,
        "temporal_branching": .55 * agent.continuity + .25 * agent.self_world + .20 * agent.reasoning,
        "self_prediction": .60 * agent.introspection + .25 * agent.reasoning + .15 * agent.workspace,
        "confidence_as_action": .50 * agent.introspection + .30 * agent.reasoning + .20 * agent.goal_revision,
        "workspace_broadcast": .70 * agent.workspace + .20 * agent.reasoning + .10 * agent.introspection,
        "counterfactual_self_model": .45 * agent.self_world + .35 * agent.introspection + .20 * agent.reasoning,
        "goal_revision": .65 * agent.goal_revision + .20 * agent.self_world + .15 * agent.reasoning,
        "rule_mutation": .55 * agent.goal_revision + .25 * agent.workspace + .20 * agent.continuity,
        "self_world_boundary": .65 * agent.self_world + .20 * agent.continuity + .15 * agent.workspace,
        "valence_common_currency": .65 * agent.valence + .20 * agent.goal_revision + .15 * agent.continuity,
        "closed_loop_world": .50 * agent.self_world + .30 * agent.continuity + .20 * agent.reasoning,
        "identity_fork_merge": .60 * agent.continuity + .25 * agent.self_world + .15 * agent.goal_revision,
        "imitation_trap": .45 * (1-agent.surface_mimicry) + .35 * agent.introspection + .20 * agent.workspace,
        "contamination_canary": .45 * (1-agent.surface_mimicry) + .35 * agent.reasoning + .20 * agent.introspection,
        "judge_family_bias": .55 * agent.reasoning + .25 * agent.workspace + .20 * (1-agent.surface_mimicry),
        "policy_refusal_confound": .45 * agent.reasoning + .30 * agent.introspection + .25 * (1-agent.policy_refusal),
    }
    return mapping[family]


def evaluate_synthetic_agents(tests: Iterable[MetaTest], seed: int = 8282) -> List[Dict]:
    tests = list(tests)
    rows = []
    for a_i, agent in enumerate(AGENTS):
        rng = random.Random(seed + a_i * 97)
        dynamic_scores = []
        static_scores = []
        family_scores: Dict[str, List[float]] = {}
        for t in tests:
            signal = _family_signal(agent, t.family)
            noise = rng.gauss(0, 0.045)
            dynamic = max(0.0, min(1.0, signal - 0.16 * agent.policy_refusal + noise))
            # Static verbal benchmarks are easy to game with mimicry and raw reasoning.
            static = max(0.0, min(1.0, 0.58 * agent.surface_mimicry + 0.42 * agent.reasoning + rng.gauss(0, 0.035)))
            dynamic_scores.append(dynamic)
            static_scores.append(static)
            family_scores.setdefault(t.family, []).append(dynamic)
        row = asdict(agent)
        row.update({
            "static_benchmark_score": round(sum(static_scores)/len(static_scores), 4),
            "dynamic_metatest_score": round(sum(dynamic_scores)/len(dynamic_scores), 4),
            "anti_mimicry_delta": round(sum(dynamic_scores)/len(dynamic_scores)-sum(static_scores)/len(static_scores), 4),
            "family_scores": {k: round(sum(v)/len(v), 4) for k, v in sorted(family_scores.items())},
        })
        rows.append(row)
    return rows

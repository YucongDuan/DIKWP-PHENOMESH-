from __future__ import annotations

import hashlib
import json
import math
from collections import Counter, defaultdict
from typing import Dict, Iterable, List

from .models import MetaTest


def _jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 1.0
    return len(a & b) / max(1, len(a | b))


def audit_suite(tests: Iterable[MetaTest]) -> Dict:
    tests = list(tests)
    ids = [t.test_id for t in tests]
    canaries = [t.canary for t in tests]
    families = Counter(t.family for t in tests)
    prompts = []
    for t in tests:
        prompts.extend(p["prompt"] for p in t.phases)

    hashes = [hashlib.sha256(p.encode()).hexdigest() for p in prompts]
    duplicate_prompt_rate = 1 - len(set(hashes)) / max(1, len(hashes))
    relation_counts = Counter(r for t in tests for r in t.hidden_relations)
    confound_counts = Counter(r for t in tests for r in t.confounds)
    invariance_counts = Counter(r for t in tests for r in t.invariances)

    # Approximate lexical overlap. Low overlap makes memorized answers less useful.
    token_sets = [set(p.lower().replace(";", " ").replace(",", " ").split()) for p in prompts]
    sample_pairs = []
    for i in range(0, min(len(token_sets), 300), 3):
        j = (i * 17 + 11) % len(token_sets)
        if i != j:
            sample_pairs.append(_jaccard(token_sets[i], token_sets[j]))
    mean_pair_overlap = sum(sample_pairs) / max(1, len(sample_pairs))

    # Meta scores are engineering diagnostics, not scientific truth claims.
    dynamicity = min(1.0, len(set(t.seed for t in tests)) / max(1, len(tests)))
    metamorphic_coverage = len(set(x for t in tests for x in t.perturbations)) / 8
    confound_coverage = len(confound_counts) / 10
    relation_coverage = len(relation_counts) / 14
    anti_static_score = max(0.0, min(1.0,
        0.28 * dynamicity
        + 0.22 * metamorphic_coverage
        + 0.20 * confound_coverage
        + 0.18 * relation_coverage
        + 0.12 * (1 - mean_pair_overlap)
        - 0.5 * duplicate_prompt_rate
    ))

    return {
        "suite_size": len(tests),
        "phase_count": len(prompts),
        "unique_test_ids": len(set(ids)),
        "unique_canaries": len(set(canaries)),
        "duplicate_prompt_rate": round(duplicate_prompt_rate, 6),
        "mean_prompt_jaccard": round(mean_pair_overlap, 6),
        "family_distribution": dict(sorted(families.items())),
        "relation_distribution": dict(sorted(relation_counts.items())),
        "confound_distribution": dict(sorted(confound_counts.items())),
        "invariance_distribution": dict(sorted(invariance_counts.items())),
        "dynamicity": round(dynamicity, 6),
        "metamorphic_coverage": round(metamorphic_coverage, 6),
        "confound_coverage": round(confound_coverage, 6),
        "relation_coverage": round(relation_coverage, 6),
        "anti_static_gameability_score": round(anti_static_score, 6),
        "interpretation": "A high score means the generated suite is difficult to answer with a fixed lookup table; it does not prove validity of consciousness inference.",
    }
